#ifndef CPGF_GMETATRAITSPARAM_H
#define CPGF_GMETATRAITSPARAM_H


namespace cpgf {

class GMetaModule;

struct GMetaTraitsParam
{
	const GMetaModule * module;
};


} // namespace cpgf


#endif
