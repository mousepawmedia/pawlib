#undef M
#undef GM

#undef ENUM_VALUE
#undef GENUM_VALUE


#undef CPGF_MD_TEMPLATE
#undef CPGF_MD_STL_QUIRK_CONST_ITERATOR
