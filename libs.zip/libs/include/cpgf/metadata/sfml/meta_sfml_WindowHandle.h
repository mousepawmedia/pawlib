// Auto generated file, don't modify.

#ifndef __META_SFML_WINDOWHANDLE_H
#define __META_SFML_WINDOWHANDLE_H


#include "cpgf/gmetadefine.h"
#include "cpgf/metadata/gmetadataconfig.h"
#include "cpgf/metadata/private/gmetadata_header.h"
#include "cpgf/gmetapolicy.h"


using namespace sf;


namespace meta_sfml { 


} // namespace meta_sfml




#include "cpgf/metadata/private/gmetadata_footer.h"


#endif
