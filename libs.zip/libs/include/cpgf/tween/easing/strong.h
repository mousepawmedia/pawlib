#ifndef CPGF_TWEEN_EASING_STRONG_H
#define CPGF_TWEEN_EASING_STRONG_H

#include "cpgf/tween/gtweencommon.h"

namespace cpgf {

typedef QuintEase StrongEase;


} // namespace cpgf


#endif
