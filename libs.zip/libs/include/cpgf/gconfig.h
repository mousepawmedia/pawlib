#ifndef CPGF_GCONFIG_H
#define CPGF_GCONFIG_H


#define G_MAX_ARITY 30

//define this macro if you want to customize it
//#define G_API_CC __stdcall


#endif

